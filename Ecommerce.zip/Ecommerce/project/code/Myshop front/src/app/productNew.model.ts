export interface ProductNew {
    _id? : string
    name : string;
     description : string;
   productImagePath : string;
   price : number;
     stock : number;
     category:string;
  }
  