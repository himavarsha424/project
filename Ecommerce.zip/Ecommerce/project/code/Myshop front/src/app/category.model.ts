export class Category
{
    public _id? : string
    public name : string;
  


    constructor(p_name:string)
    {

        this.name = p_name;
      

    }
}