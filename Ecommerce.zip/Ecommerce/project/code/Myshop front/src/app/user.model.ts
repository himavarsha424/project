export class User
{
    public _id? : string
    public name : string;
    public lastname : string;
    public email : string;
    public address : number;
    public password : number;


}